# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pymtgfall']

package_data = \
{'': ['*']}

install_requires = \
['httpx-caching>=0.1a2,<0.2',
 'httpx>=0.22.0,<0.23.0',
 'loguru>=0.6.0,<0.7.0',
 'pytest>=7.1.1,<8.0.0',
 'trio>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'pymtgfall',
    'version': '0.4.0',
    'description': '',
    'long_description': None,
    'author': 'Thomas TJ Dau',
    'author_email': 'tj.pyro@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
